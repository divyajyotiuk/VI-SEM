package com.pogo;

public interface FortuneService {

	
	public String getFortune();
}
