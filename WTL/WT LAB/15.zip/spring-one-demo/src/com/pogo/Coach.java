package com.pogo;

public interface Coach {
	public String getDailyWorkout();
	
	public String getDailyFortune();
}
